#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "iec104::iec104" for configuration "Release"
set_property(TARGET iec104::iec104 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(iec104::iec104 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libiec104.so.0.3.0"
  IMPORTED_SONAME_RELEASE "libiec104.so.0"
  )

list(APPEND _cmake_import_check_targets iec104::iec104 )
list(APPEND _cmake_import_check_files_for_iec104::iec104 "${_IMPORT_PREFIX}/lib/libiec104.so.0.3.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
